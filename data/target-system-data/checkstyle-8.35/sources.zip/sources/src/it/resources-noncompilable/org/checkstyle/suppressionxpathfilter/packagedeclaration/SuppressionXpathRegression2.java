// non-compiled with javac: missing package. Used for Testing purpose.
// package is missing.
public class SuppressionXpathRegression2 { // warn
	// code
}

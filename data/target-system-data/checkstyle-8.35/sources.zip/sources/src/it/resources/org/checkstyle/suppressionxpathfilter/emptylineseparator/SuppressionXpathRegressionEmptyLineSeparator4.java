///////////////////////////////////////////////////
//HEADER
///////////////////////////////////////////////////

package org.checkstyle.suppressionxpathfilter.emptylineseparator;

class SuppressionXpathRegressionEmptyLineSeparator4 {
    public static final int FOO_CONST = 1;

    public void foo() {}

    public void foo1() {} // warn


}

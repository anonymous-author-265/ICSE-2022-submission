package org.checkstyle.suppressionxpathfilter.classmemberimpliedmodifier;

public class SuppressionXpathRegressionClassMemberImpliedModifierOne {
    public interface Foo { //warn
    }
}

package com.google.checkstyle.test.chapter5naming.rule521_packagenames; //warn
final class InputBadPackageName2 {}

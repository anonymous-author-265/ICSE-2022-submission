package org.checkstyle.suppressionxpathfilter.annotationusestyle;

@Deprecated
@SuppressWarnings(value={"foo"}) //warn
public class SuppressionXpathRegressionAnnotationUseStyleSeven {

}

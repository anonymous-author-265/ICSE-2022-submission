package org.checkstyle.suppressionxpathfilter.abstractclassname;

public class SuppressionXpathRegressionAbstractClassNameInner {
    abstract class MyClass { // warn
    }
}

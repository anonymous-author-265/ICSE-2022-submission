package org.checkstyle.suppressionxpathfilter.annotationonsameline;

@Deprecated //warn
interface SuppressionXpathRegressionAnnotationOnSameLineThree {

}

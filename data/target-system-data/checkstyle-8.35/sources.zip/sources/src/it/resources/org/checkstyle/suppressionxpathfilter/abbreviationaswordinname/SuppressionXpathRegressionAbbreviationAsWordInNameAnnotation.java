package org.checkstyle.suppressionxpathfilter.abbreviationaswordinname;

public class SuppressionXpathRegressionAbbreviationAsWordInNameAnnotation {

    @interface ANNOTATION { // warn

    }

}

package org.checkstyle.suppressionxpathfilter.avoidescapedunicodecharacters;

public class SuppressionXpathRegressionAvoidEscapedUnicodeCharactersDefault {
    private String unitAbbrev2 = "\u03bcs"; /* warn */
}

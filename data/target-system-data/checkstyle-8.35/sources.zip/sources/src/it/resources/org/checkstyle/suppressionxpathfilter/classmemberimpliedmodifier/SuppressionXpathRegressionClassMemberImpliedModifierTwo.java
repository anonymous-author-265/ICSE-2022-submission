package org.checkstyle.suppressionxpathfilter.classmemberimpliedmodifier;

public class SuppressionXpathRegressionClassMemberImpliedModifierTwo {
    public enum Count { //warn
        ONE, TWO, THREE;
    }
}

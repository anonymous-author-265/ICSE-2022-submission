package org.checkstyle.suppressionxpathfilter.commentsindentation;

public class SuppressionXpathRegressionCommentsIndentationSeparator {
    public void main(String[] args) {
        int n;
    }

            /////////////// Comment separator // warn

    public void foo() {
    }
}

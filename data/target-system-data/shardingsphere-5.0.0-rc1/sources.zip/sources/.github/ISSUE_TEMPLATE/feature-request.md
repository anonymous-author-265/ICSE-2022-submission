---
name: "\U0001F680 Feature Request"
about: I have a suggestion
---

## Feature Request

**For English only**, other languages will not accept.

Please pay attention on issues you submitted, because we maybe need more details. 
If no response anymore and we cannot make decision by current information, we will **close it**.

Please answer these questions before submitting your issue. Thanks!

### Is your feature request related to a problem?

### Describe the feature you would like.

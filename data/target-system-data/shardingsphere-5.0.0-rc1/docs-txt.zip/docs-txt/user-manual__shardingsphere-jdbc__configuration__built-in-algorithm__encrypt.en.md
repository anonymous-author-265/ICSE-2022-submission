+++
title = "Encryption Algorithm"
weight = 4
+++

## MD5 Encrypt Algorithm

Type: MD5

Attributes: None

## AES Encrypt Algorithm

Type: AES

Attributes:

| *Name*        | *DataType* | *Description* |
| ------------- | ---------- | ------------- |
| aes.key.value | String     | AES KEY       |

## RC4 Encrypt Algorithm

Type: RC4

Attributes:

| *Name*        | *DataType* | *Description* |
| ------------- | ---------- | ------------- |
| rc4.key.value | String     | RC4 KEY       |

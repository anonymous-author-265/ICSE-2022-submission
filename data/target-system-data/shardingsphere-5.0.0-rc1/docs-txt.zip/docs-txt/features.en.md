+++
pre = "<b>3. </b>"
title = "Concepts & Features"
weight = 3
chapter = true
+++

This chapter describes concepts and features about Apache ShardingSphere. Please refer to [User manual](/en/user-manual/) for more details.

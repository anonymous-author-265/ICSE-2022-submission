+++
pre = "<b>2. </b>"
title = "Quick Start"
weight = 2
chapter = true
+++

In shortest time, this chapter provides users with a simplest quick start with Apache ShardingSphere.
+++
pre = "<b>4. </b>"
title = "User Manual"
weight = 4
chapter = true
+++

This chapter describe how to use projects of Apache ShardingSphere: ShardingSphere-JDBC, ShardingSphere-Proxy and ShardingSphere-Sidecar.
Except main projects, this chapter also describe how to use derivative projects of Apache ShardingSphere: ShardingSphere-Scaling and ShardingSphere-UI.

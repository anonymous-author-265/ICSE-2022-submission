+++
title = "Load Balance Algorithm"
weight = 3
+++

## Round Robin Algorithm

Type: ROUND_ROBIN

Attributes: None

## Random Algorithm

Type: RANDOM

Attributes: None

+++
title = "Multi Replica"
weight = 5
+++

## Root Configuration

Class name: org.apache.shardingsphere.replica.api.config.ReplicaRuleConfiguration

TODO

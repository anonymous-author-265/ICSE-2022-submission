+++
title = "Governance"
weight = 3
chapter = true
+++

Using governance requires designating a config center, registry center & metadata center, in which all the configurations are saved. 
Users can either use local configurations to cover config center configurations or read configurations from config center.

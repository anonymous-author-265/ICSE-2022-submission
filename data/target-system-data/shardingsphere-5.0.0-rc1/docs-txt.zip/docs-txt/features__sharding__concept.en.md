+++
pre = "<b>3.1.1. </b>"
title = "Core Concept"
weight = 1
chapter = true
+++

## Overview

This chapter is to introduce core concepts of data sharding, including:

- Core concepts of SQL
- Core concepts of sharding
- Core concepts of configuration

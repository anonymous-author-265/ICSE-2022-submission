+++
pre = "<b>3.2.1. </b>"
title = "Core Concept"
weight = 1
chapter = true
+++

## Navigation

This chapter mainly introduces the core concepts of distributed transactions, including:

* 2PC transaction with XA
* BASE transaction with Seata

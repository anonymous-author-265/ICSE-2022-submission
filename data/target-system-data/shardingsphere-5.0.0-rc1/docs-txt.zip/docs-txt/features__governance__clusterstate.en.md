+++
pre = "<b>3.4.3 </b>"
title = "Cluster"
weight = 3
chapter = true
+++

## Navigation

This chapter mainly introduces the features of the cluster:

* Heartbeat check
* Cluster state topology

+++
pre = "<b>3.4.1 </b>"
title = "Management"
weight = 1
chapter = true
+++

## Navigation

This chapter mainly introduces the features of the distributed governance:

* Config center
* Registry center
* Metadata center
* Third-party components dependency

+++
pre = "<b>4.4. </b>"
title = "ShardingSphere-Scaling"
weight = 4
chapter = true
+++

## Introduction

ShardingSphere-Scaling is a common solution for migrating data to ShardingSphere or scaling data in Apache ShardingSphere since **4.1.0**, current state is **Alpha** version.

+++
pre = "<b>3.4.2 </b>"
title = "Observability"
weight = 2
chapter = true
+++

## Navigation

This chapter mainly introduces the features of the observability:

* APM Integration
* Metrics

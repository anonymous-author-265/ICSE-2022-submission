+++
pre = "<b>4.2.1. </b>"
title = "Usage"
weight = 1
+++

This chapter will introduce the use of ShardingSphere-Proxy. 
Please refer to [Example](https://github.com/apache/shardingsphere/tree/master/examples) for more details.

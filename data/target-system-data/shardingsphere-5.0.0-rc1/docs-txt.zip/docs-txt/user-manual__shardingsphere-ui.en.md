+++
pre = "<b>4.5. </b>"
title = "ShardingSphere-UI"
weight = 5
chapter = true
+++

## Introduction

ShardingSphere-UI is a simple and useful web administration console for ShardingSphere. 
It is designed to help users more easily use ShardingSphere, and currently provides ability of registry center management, dynamic configuration management, database orchestration, etc.

The frontend of project uses vue as javascript framework and the backend is a standard spring boot project. 
You can deploy it with maven, and also run locally by separating the frontend and backend.

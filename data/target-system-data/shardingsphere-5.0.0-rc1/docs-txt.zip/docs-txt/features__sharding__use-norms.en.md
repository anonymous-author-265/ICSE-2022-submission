+++
pre = "<b>3.1.3. </b>"
title = "Use Norms"
weight = 3
+++

## Background

Though Apache ShardingSphere intends to be compatible with all the SQLs and stand-alone databases, the distributed scenario has brought more complex situations to the database. 
Apache ShardingSphere wants to solve massive data OLTP problem first and complete relevant OLAP support problem little by little.

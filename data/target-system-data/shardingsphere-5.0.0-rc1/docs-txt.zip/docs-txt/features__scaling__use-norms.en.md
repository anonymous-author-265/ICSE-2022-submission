+++
pre = "<b>3.5.3. </b>"
title = "User Norms"
weight = 3
+++

## Supported Items

* Migrate out data into databases which managed by Apache ShardingSphere;
* Scale out data between data nodes of Apache ShardingSphere.

## Unsupported Items

* Do not support to scale tables without primary key.

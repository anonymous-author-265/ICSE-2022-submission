+++
title = "YAML Syntax"
weight = 4
+++

`!!` means instantiation of that class

`!` means self-defined alias

`-` means one or multiple can be included

`[]` means array, can substitutable with `-` each other

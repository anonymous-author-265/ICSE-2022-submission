+++
pre = "<b>3.2.2. </b>"
title = "Principle"
weight = 2
chapter = true
+++

## Navigation

This chapter mainly introduces the principles of the distributed transactions:

* 2PC transaction with XA
* BASE transaction with Seata

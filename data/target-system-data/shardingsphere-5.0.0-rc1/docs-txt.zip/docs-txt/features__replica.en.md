+++
pre = "<b>3.8. </b>"
title = "Multi replica"
weight = 8
chapter = true
+++

## Navigation

TODO

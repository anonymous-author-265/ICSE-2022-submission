+++
pre = "<b>4.1.1. </b>"
title = "Usage"
weight = 1
chapter = true
+++

This chapter will introduce the use of ShardingSphere-JDBC. 
Please refer to [Example](https://github.com/apache/shardingsphere/tree/master/examples) for more details.

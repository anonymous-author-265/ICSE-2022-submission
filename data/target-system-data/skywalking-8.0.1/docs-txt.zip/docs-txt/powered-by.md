# Powered by Apache SkyWalking
This page documents an **alphabetical list** of institutions that are using Apache SkyWalking for research and production,
or providing commercial products including Apache SkyWalking.

1. 17173.com https://www.17173.com/
1. 300.cn 中企动力科技股份有限公司 http://www.300.cn/
1. 360jinrong.net 360金融 https://www.360jinrong.net/
1. 4399.com 四三九九网络股份有限公司. http://www.4399.com/
1. 51mydao.com 买道传感科技（上海）有限公司 https://www.51mydao.com/
1. 58 Daojia Inc. 58到家 https://www.daojia.com
1. 5i5j. 上海我爱我家房地产经纪有限公司 https://sh.5i5j.com/about/
1. Anheuser-Busch InBev 百威英博
1. Agricultural Bank of China 中国农业银行
1. Aihuishou.com 爱回收网 http://www.aihuishou.com/
1. Alibaba Cloud, 阿里云, http://aliyun.com
1. Anxin Insurance. 安心财产保险有限责任公司 https://www.95303.com
1. APM Star 北京天空漫步科技有限公司 http://www.apmstar.com
1. AsiaInfo Inc. http://www.asiainfo.com.cn/
1. Autohome. 汽车之家. http://www.autohome.com.cn
1. baidu 百度 https://www.baidu.com/
1. Baixing.com 百姓网 http://www.baixing.com/
1. bitauto 易车 http://bitauto.com
1. hellobanma 斑马网络 https://www.hellobanma.com/
1. bestsign. 上上签. https://www.bestsign.cn/page/
1. Beike Finance 贝壳金服 https://www.bkjk.com/
1. Bizsaas.cn 北京商云科技发展有限公司. http://www.bizsaas.cn/
1. Cdlhyj.com 六合远教（成都）科技有限公司 http://www.cdlhyj.com
1. Chehejia Automotive. 北京车和家信息技术有限责任公司. https://www.chehejia.com/
1. China Eastern Airlines 中国东方航空 http://www.ceair.com/
1. China Express Airlines 华夏航空 http://www.chinaexpressair.com/
1. Chinadaas. 北京中数智汇科技股份有限公司. https://www.chinadaas.com/
1. Chinasoft International 中软国际
1. China Merchants Bank. 中国招商银行. http://www.cmbchina.com/
1. China National Software 中软
1. China Mobile 中国移动
1. China Unicom 中国联通
1. China Tower 中国铁塔
1. China Telecom 中国电信
1. Chinese Academy of Sciences
1. Chtwm.com. 恒天财富投资管理股份有限公司. https://www.chtwm.com/
1. Cmft.com. 招商局金融科技. https://www.cmft.com/
1. CXIST.com 上海程析智能科技有限公司 https://www.cxist.com/
1. Dangdang.com. 当当网. http://www.dangdang.com/
1. DaoCloud. https://www.daocloud.io/
1. deepblueai.com 深兰科技上海有限公司 https://www.deepblueai.com/
1. Deppon Logistics Co Ltd 德邦物流 https://www.deppon.com/
1. Deyoushenghuo in WeChat app. 河南有态度信息科技有限公司，微信小程序：得有生活
1. Dianfubao.com 垫富宝 https://www.dianfubao.com/
1. DiDi 滴滴出行
1. Echplus.com 北京易诚互动网络技术有限公司 http://www.echplus.com/
1. Enmonster 怪兽充电 http://www.enmonster.com/
1. Eqxiu.com. 北京中网易企秀科技有限公司 http://www.eqxiu.com/
1. fangdd.com 房多多 https://www.fangdd.com
1. fullgoal.com.cn 富国基金管理有限公司 https://www.fullgoal.com.cn/
1. GTrace System. (No company provided)
1. GSX Techedu Inc. 跟谁学 https://www.genshuixue.com
1. Gdeng.cn 深圳谷登科技有限公司 http://www.gdeng.cn/
1. GOME 国美 https://www.gome.com.cn/
1. Guazi.com 瓜子二手车直卖网. https://www.guazi.com/
1. guohuaitech.com 北京国槐信息科技有限公司. http://www.guohuaitech.com/
1. GrowingIO 北京易数科技有限公司 https://www.growingio.com/
1. Haier. 海尔消费金融 https://www.haiercash.com/
1. Haoyunhu. 上海好运虎供应链管理有限公司 http://www.haoyunhu56.com/
1. helijia.com 河狸家 http://www.helijia.com/
1. Huawei
1. Hundun YUNRONG Fintech. 杭州恒生云融网络科技有限公司 https://www.hsjry.com/
1. hunliji.com 婚礼纪 https://www.hunliji.com/
1. hydee.cn 海典软件 http://www.hydee.cn/
1. iBoxChain 盒子科技 https://www.iboxpay.com/
1. iFLYTEK. 科大讯飞股份有限公司-消费者BG http://www.iflytek.com/
1. Inspur 浪潮集团
1. juhaokan 聚好看科技股份有限公司 https://www.juhaokan.org/
1. Ke.com. 贝壳找房. https://www.ke.com
1. Keking.cn 凯京集团. http://www.keking.cn
1. KubeSphere https://kubesphere.io
1. JoinTown. 九州通医药集团 http://www.jztey.com/
1. Lagou.com. 拉勾. https://www.lagou.com/
1. laocaibao. 上海证大爱特金融信息服务有限公司 https://www.laocaibao.com/
1. Lenovo 联想
1. liaofan168.com 了凡科技 http://www.liaofan168.com
1. lianzhongyouche.com.cn 联众优车  https://www.lianzhongyouche.com.cn/
1. Lima 北京力码科技有限公司 https://www.zhongbaounion.com/
1. Lifesense.com 广东乐心医疗电子股份有限公司 http://www.lifesense.com/
1. lizhi.fm 荔枝FM https://www.lizhi.fm/
1. Lixiang.com 理想汽车 https://www.lixiang.com/
1. Madecare. 北京美德远健科技有限公司. http://www.madecare.com/
1. Maodou.com 毛豆新车网. https://www.maodou.com/
1. Mobanker.com 上海前隆信息科技有限公司  http://www.mobanker.com/
1. Mxnavi. 沈阳美行科技有限公司 http://www.mxnavi.com/
1. Moji 墨叽（深圳）科技有限公司 https://www.mojivip.com
1. Minsheng FinTech / China Minsheng Bank 民生科技有限责任公司 http://www.mskj.com/
1. Migu Digital Media Co.Ltd. 咪咕数字传媒有限公司 http://www.migu.cn/
1. Mypharma.com 北京融贯电子商务有限公司 https://www.mypharma.com
1. NetEase 网易 https://www.163.com/
1. Osacart in WeChat app 广州美克曼尼电子商务有限公司
1. Oriente. https://oriente.com/
1. Peking University 北京大学
1. Ping An Technology / Ping An Insurance 平安科技
1. Primeton.com 普元信息技术股份有限公司 http://www.primeton.com
1. qiniu.com 七牛云 http://qiniu.com
1. Qingyidai.com 轻易贷 https://www.qingyidai.com/
1. Qsdjf.com 浙江钱宝网络科技有限公司 https://www.qsdjf.com/index.html
1. Qk365.com 上海青客电子商务有限公司 https://www.qk365.com
1. Qudian 趣店 http://ir.qudian.com/
1. Renren Network 人人网
1. Rong Data. 荣数数据 http://www.rong-data.com/
1. Rongjinbao. 深圳融金宝互联网金融服务有限公司. http://www.rjb777.com
1. Safedog. 安全狗. http://www.safedog.cn/
1. servingcloud.com 盈佳云创科技(深圳)有限公司 http://www.servingcloud.com/
1. SF Express 顺丰速运 https://www.sf-express.com/
1. Shouqi Limousine & chauffeur Group 首约科技(北京)有限公司. https://www.01zhuanche.com/
1. shuaibaoshop.com 宁波鲸灵网络科技有限公司 http://www.shuaibaoshop.com/
1. shuyun.com 杭州数云信息技术有限公司 http://www.shuyun.com/
1. Sijibao.com 司机宝 https://www.sijibao.com/
1. Sina 新浪
1. Sinolink Securities Co.,Ltd. 国金证券佣金宝 http://www.yongjinbao.com.cn/
1. Source++ https://sourceplusplus.com
1. SPD Bank 浦发银行
1. StartDT 奇点云 https://www.startdt.com/
1. State Grid Corporation of China 国家电网有限公司
1. Successchannel 苏州渠成易销网络科技有限公司. http://www.successchannel.com
1. SuperMap 北京超图软件
1. syswin.com 北京思源集团 http://www.syswin.com/
1. szhittech.com 深圳和而泰智能控制股份有限公司. http://www.szhittech.com/
1. Tencent
1. Tetrate.io https://www.tetrate.io/
1. Thomas Cook 托迈酷客 https://www.thomascook.com.cn
1. Three Squirrels 三只松鼠
1. Today36524.com Today便利店
1. Tongcheng. 同城金服. https://jr.ly.com/
1. Tools information technology co. LTD 杭州图尔兹信息技术有限公司 http://bintools.cn/
1. TravelSky 中国航信 http://www.travelsky.net/
1. Tsfinance.com 重庆宜迅联供应链科技有限公司 https://www.tsfinance.com.cn/
1. tuhu.cn 途虎养车 https://www.tuhu.cn
1. Tuya. 涂鸦智能. https://www.tuya.com
1. Tydic 天源迪科 https://www.tydic.com/
1. VBill Payment Co., LTD. 随行付. https://www.vbill.cn/
1. Wahaha Group 娃哈哈 http://www.wahaha.com.cn/
1. WeBank. 微众银行 http://www.webank.com
1. Weier. 广州文尔软件科技有限公司. https://www.site0.cn
1. Wochu. 我厨买菜. https://www.wochu.cn
1. Xiaomi. 小米. https://www.mi.com/en/
1. xin.com 优信集团 http://www.xin.com
1. Xinyebang.com 重庆欣业邦网络技术有限公司 http://www.xinyebang.com
1. xueqiu.com 雪球财经. https://xueqiu.com/
1. yibainetwork.com 深圳易佰网络有限公司 http://www.yibainetwork.com/
1. Yiguo. 易果生鲜. http://www.yiguo.com/
1. Yinji(shenzhen)Network Technology Co.,Ltd. 印记. http://www.yinjiyun.cn/
1. Yonghui Superstores Co., Ltd. 永辉超市 http://www.yonghui.com.cn
1. Yonyou 用友
1. Youzan.com 杭州有赞科技有限公司 http://www.youzan.com/
1. Yunda Express 韵达快运 http://www.yunda56.com/
1. Yunnan Airport Group Co.,Ltd. 云南机场集团
1. yxt 云学堂 http://www.yxt.com/
1. zbj.com 猪八戒 https://www.zbj.com/
1. zhaopin.com 智联招聘 https://www.zhaopin.com/
1. zjs.com.cn 北京宅急送快运股份有限公司 http://www.zjs.com.cn/

# Use Cases
## Alibaba and Alibaba Cloud
Alibaba products including [Cloud DevOps product](https://cn.aliyun.com/product/yunxiao) are under SkyWalking monitoring.

Alibaba Cloud supports SkyWalking agents and formats in Tracing Analysis cloud service.

## China Eastern Airlines
Integrated in the microservices architecture support platform.

## China Merchants Bank
Use SkyWalking and [SkyAPM .net agent](https://github.com/SkyAPM/SkyAPM-dotnet) in the CMBChina Mall project.

## China Mobile
China Mobile Suzhou Research Center, CMSS, integrated SkyWalking as the APM component in China Mobile PAAS.

## ke.com
Deploy SkyWalking in production environments.
- Three CentOs Machines(32 CPUs, 64G RAM, 1.3T Disk) for Collector Server
- Three ElasticSearch(Version 6.4.2, 40 CPUs, 96G RAM, 7T Disk) Nodes for Storage

Support 60+ Instances, Over 300k Calls Per Minute, Over 50k Spans Per Second

## guazi.com
Guazi.com uses SkyWalking monitoring 270+ services,
including topology + metrics analysis, and collecting 1.1+ billion traces per day with 100% sampling.

Plan is 1k+ services and 5 billion traces per day.

## Oscart
Use multiple language agents from SkyWalking and its ecosystem, including SkyWalking Javaagent and [SkyAPM nodejs agent](https://github.com/SkyAPM/SkyAPM-nodejs). SkyWalking OAP platform acts as backend and visualization.

## Primeton
Integrated in Primeton EOS PLATFORM 8, which is a commercial micro-service platform.

## Qiniu Cloud
Provide a customized version SkyWalking agent. It could provide distributed tracing and integrated in its intelligence log management platform.

## Source++
An open-source observant programming assistant which aims to bridge APM tools with the developer's IDE to enable tighter feedback loops. Source++ uses SkyWalking as the defacto APM for JVM-based applications.

## Tetrate
Tetrate provides enterprise level service mesh. SkyWalking acts as the core observability platform for hybrid
enterprise service mesh environment.

## lagou.com
Lagou.com use Skywalking for JVM-based applications, deployed in production. Custom and optimize muiti collector functions, such as alarm, sql metric, circle operation metric, thread monitor, detail mode. Support 200+ Instances, over 4500k Segments Per Minute.

## Yonghui Superstores
Yonghui Superstores Co., Ltd. use SkyWalking as primary APM system, to monitor 1k+ instances clusters, which supports 150k+ tps/qps payload. SkyWalking collect, analysis and save 10 billions trace segments(cost 3T disk) each day in 100% sampling strategy. SkyWalking backend cluster is built with 15 nodes OAP and 20 nodes ElasticSearch.

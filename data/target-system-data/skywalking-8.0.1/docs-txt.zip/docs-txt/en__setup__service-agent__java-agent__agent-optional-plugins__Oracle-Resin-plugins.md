## Oracle and Resin plugins
These plugins can't be provided in Apache release because of Oracle and Resin Licenses.
If you want to know details, please read [Apache license legal document](https://www.apache.org/legal/resolved.html)

Due to license incompatibilities/restrictions these plugins are hosted and released in 3rd part repository, 
go to [OpenSkywalking java plugin extension repository](https://github.com/OpenSkywalking/java-plugin-extensions) to get these.

# JVM Metrics Service
## Abstract
Uplink the JVM metrics, including PermSize, HeapSize, CPU, Memory, etc., every second.

[gRPC service define](https://github.com/apache/skywalking-data-collect-protocol/blob/v2.0/JVMMetricsService.proto)
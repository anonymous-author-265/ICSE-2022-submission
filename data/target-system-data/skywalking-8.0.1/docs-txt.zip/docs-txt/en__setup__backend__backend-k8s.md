# Deploy SkyWalking backend and UI in kubernetes

Follow instructions in the [deploying SkyWalking backend to Kubernetes cluster](https://github.com/apache/skywalking-kubernetes)
 to deploy oap and ui to a kubernetes cluster.
 
Please read the Readme file.
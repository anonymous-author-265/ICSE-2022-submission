# Replace string

This feature is available through **Search → Replace string...**.


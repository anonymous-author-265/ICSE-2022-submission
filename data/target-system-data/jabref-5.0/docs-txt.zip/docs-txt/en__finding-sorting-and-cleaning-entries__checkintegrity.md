# Check integrity

JabRef can check the integrity of a database.

This feature is available through **Quality → Check integrity...**.


# Manage external file types

This feature is available through **Options → Manage external file types**.


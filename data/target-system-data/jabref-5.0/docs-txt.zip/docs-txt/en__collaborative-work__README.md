# Share

JabRef allows to share both Bib\(La\)TeX database and [SQL database](sqldatabase/).


---
description: Learn how to add new literature to JabRef.
---

# Collect

There are several ways to add a new entry.


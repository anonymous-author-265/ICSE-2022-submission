# Configuration

JabRef can be configured in various ways.


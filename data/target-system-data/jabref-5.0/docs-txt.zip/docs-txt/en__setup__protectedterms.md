# Manage protected terms

This feature is available through **Options → Manage protected terms**.


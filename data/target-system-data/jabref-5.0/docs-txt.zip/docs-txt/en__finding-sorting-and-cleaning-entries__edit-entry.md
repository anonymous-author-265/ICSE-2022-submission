# Edit entry

To open an [entry editor](../advanced/entryeditor/) for an existing entry, simply double-click anywhere on the appropriate line will open the entry editor \(or select the entry and press Enter\).


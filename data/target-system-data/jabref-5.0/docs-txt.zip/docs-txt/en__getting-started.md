# Getting started

{% hint style="info" %}
Coming soon!
{% endhint %}

Desktop interface \(basic description of the user interface elements and what they do\)

Quick start \(basic userflow: create new library -&gt; add entry, link file, do web search -&gt; save\)


# Organize

How to find, sort, and clean entries

{% hint style="info" %}
The following still needs to be described: add keywords, mark entries as read + rank them
{% endhint %}


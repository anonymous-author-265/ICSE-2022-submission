# License

### The license of the JabRef software

The JabRef software is under the [MIT License](https://github.com/JabRef/jabref/blob/master/LICENSE.md). In short, JabRef is free to use, even commercially. You can also redistribute and modify JabRef as long as you include the original copyright and license notice in any copy of the software/source.

### The license of the JabRef documentation

The documentation of JabRef is under the [Creative Commons 4.0 Attribution 4.0 International License](https://github.com/JabRef/user-documentation/blob/master/LICENSE.md). In short, you can make a commercial use of it, distribute it, modify it and rename it. You must give credit, include copyright, and state changes. And you cannot sublicense it.


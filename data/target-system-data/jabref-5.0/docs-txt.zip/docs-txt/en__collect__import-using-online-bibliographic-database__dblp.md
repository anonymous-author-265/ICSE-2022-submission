# DBLP

[DBLP](http://dblp.uni-trier.de/db/) is a computer science bibliography website listing more than 3.1 million journal articles, conference papers, and other publications on computer science \([Wikipedia](https://en.wikipedia.org/wiki/DBLP)\).


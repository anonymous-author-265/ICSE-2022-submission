# Customize key bindings

This feature is available through **Options → Customize key bindings**.

You can reset the key bindings to default by pressing the "Default" button. This is especially useful when upgrading from a JabRef version before 3.8.2.


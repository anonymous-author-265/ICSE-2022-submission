---
title: Error while updating citation styles
labels: code-quality, dependencies
---
[Update of citation styles failed!](https://github.com/JabRef/jabref/actions?query=workflow%3A%22Refresh+Citation+Style+Language+Files%22) 

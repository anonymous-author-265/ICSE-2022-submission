# Architectural Decisions

This directory contains the architectural decisions for JabRef.

For new ADRs, please use [template.md](template.md) as basis.
More information on the used format is available at <https://adr.github.io/madr/>.
General information about architectural decision records is available at <https://adr.github.io/>.

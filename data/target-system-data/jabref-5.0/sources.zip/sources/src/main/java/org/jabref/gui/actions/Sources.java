package org.jabref.gui.actions;

public enum Sources {
    FromButton,
    FromMenu

}

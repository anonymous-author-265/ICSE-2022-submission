package org.jabref.gui.groups;

public enum GroupViewMode {

    INTERSECTION,
    UNION,

}

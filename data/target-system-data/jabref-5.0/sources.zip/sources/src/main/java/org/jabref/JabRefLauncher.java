package org.jabref;

/**
 * JabRef launcher: This just starts JabRefMain. It is there because to have the name consistent to other Java applications.
 */
public class JabRefLauncher {
    public static void main(String[] args) {
        JabRefMain.main(args);
    }
}

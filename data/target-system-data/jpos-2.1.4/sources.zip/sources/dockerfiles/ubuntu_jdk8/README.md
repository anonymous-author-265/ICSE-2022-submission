# Build 

```
docker build -t="jpos/ubuntu_jdk8" .
```

# Run

```
docker run -t -i jpos/ubuntu_jdk8 /bin/bash
```

# Push

```
docker push jpos/ubuntu_jdk8
```


# Build 

```
docker build -t="jpos/ubuntu_vivid_jdk8" .
```

# Run

```
docker run -t -i jpos/ubuntu_vivid_jdk8 /bin/bash
```


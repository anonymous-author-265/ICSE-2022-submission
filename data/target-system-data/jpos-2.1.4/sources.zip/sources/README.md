[![][jpos-logo]][jpos-url]
[![Build Status][badge-travis-image]][badge-travis-url]
[![Javadocs](http://www.javadoc.io/badge/org.jpos/jpos.svg)](http://www.javadoc.io/doc/org.jpos/jpos)

## Documentation

Visit [http://jpos.org/learn](http://jpos.org/learn).

## Resources

Visit [http://jpos.org/resources](http://jpos.org/resources) for additional information.

        
## License

Affero GPLv3 Visit [http://jpos.org/license](http://jpos.org/license).

Commercial-friendly licensing available: [Contact form](http://jpos.org/main/contact?p=license).

[jpos-logo]: http://jpos.org/images/jpos_l.jpg
[jpos-url]: http://jpos.org
[badge-travis-url]: https://travis-ci.org/jpos/jPOS
[badge-travis-image]: https://api.travis-ci.org/jpos/jPOS.svg
[![Gitter](https://badges.gitter.im/jpos/jPOS.svg)](https://gitter.im/jpos/jPOS?utm_source=badge&utm_medium=badge&utm_campaign=pr-badge)


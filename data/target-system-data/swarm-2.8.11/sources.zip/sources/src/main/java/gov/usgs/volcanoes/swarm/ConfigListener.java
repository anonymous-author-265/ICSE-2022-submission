package gov.usgs.volcanoes.swarm;

public interface ConfigListener {
    public void settingsChanged();
}

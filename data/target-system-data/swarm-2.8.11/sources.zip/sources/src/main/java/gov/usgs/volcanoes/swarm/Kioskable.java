package gov.usgs.volcanoes.swarm;

/**
 * $Log: not supported by cvs2svn $
 * @author Dan Cervelli
 */
public interface Kioskable
{
	public void setKioskMode(boolean b);
}

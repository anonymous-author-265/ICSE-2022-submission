Winston Client
=====================

[![Build Status](https://travis-ci.org/usgs/WinstonClient.png)](https://travis-ci.org/usgs/WinstonClient)

A client for the [Winston Wave Server](https://volcanoes.usgs.gov/software/winston)

Winston
=====================

[![Build Status](https://travis-ci.org/usgs/winston.png)](https://travis-ci.org/usgs/winston)

A Java application suite used for storing, serving, and plotting seismic data. 

[User documentation](src/main/resources/docs/index.md)

[Developer documentation](http://usgs.github.io/winston)
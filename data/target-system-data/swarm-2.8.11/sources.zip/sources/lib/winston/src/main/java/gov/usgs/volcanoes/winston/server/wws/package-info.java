/**
 * A collection of classes which fulfill requests using the WWS protocol.
 * 
 * @author Tom Parker
 */

package gov.usgs.volcanoes.winston.server.wws;

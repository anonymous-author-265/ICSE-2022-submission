package gov.usgs.volcanoes.winston.db;

public class DbException extends Exception {

  /**
   * 
   */
  private static final long serialVersionUID = 1L;

  public DbException(String message) {
    super(message);
  }
}

 volcano-core
==============

[![Build Status](https://travis-ci.org/usgs/volcano-core.png)](https://travis-ci.org/usgs/volcano-core)
[![Coverage Status](https://coveralls.io/repos/usgs/volcano-core/badge.svg?branch=master&service=github)](https://coveralls.io/github/usgs/volcano-core?branch=master)

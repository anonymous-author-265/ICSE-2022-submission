package gov.usgs.volcanoes.core.legacy.net;

/**
 * 
 * $Log: not supported by cvs2svn $
 * @author Dan Cervelli
 */
public interface ReadListener {
  public void readProgress(double p);
}

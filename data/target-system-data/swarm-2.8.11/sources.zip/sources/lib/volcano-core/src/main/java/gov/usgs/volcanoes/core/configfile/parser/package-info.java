/**
 * Parsers to extract values from parameters provided in a config file.
 * 
 */
package gov.usgs.volcanoes.core.configfile.parser;

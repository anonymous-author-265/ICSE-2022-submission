package gov.usgs.volcanoes.core.quakeml;

public enum EvaluationStatus {

  PRELIMINARY, CONFIRMED, REVIEWED, FINAL, REJECTED
}

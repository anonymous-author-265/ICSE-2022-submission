/**
 * Classes to perform mathematical functions.
 * 
 */
package gov.usgs.volcanoes.core.math;

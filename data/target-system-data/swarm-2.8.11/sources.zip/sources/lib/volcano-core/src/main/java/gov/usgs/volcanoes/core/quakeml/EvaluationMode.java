package gov.usgs.volcanoes.core.quakeml;

public enum EvaluationMode {

  MANUAL, AUTOMATIC
}

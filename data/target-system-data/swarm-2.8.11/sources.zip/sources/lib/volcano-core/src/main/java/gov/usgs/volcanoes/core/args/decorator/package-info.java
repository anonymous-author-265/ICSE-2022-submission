/**
 * Concrete ConfigFile decorator classes.
 *
 * @see gov.usgs.volcanoes.core.args.ArgsDecorator
 *
 */
package gov.usgs.volcanoes.core.args.decorator;

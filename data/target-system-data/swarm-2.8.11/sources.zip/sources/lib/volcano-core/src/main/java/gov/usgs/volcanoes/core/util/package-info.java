/**
 * Mostly, but not exclusively, utility classes.
 *
 */
package gov.usgs.volcanoes.core.util;

/**
 * Convenience classes used across multiple Volcano Science Center projects. 
 *
 */
package gov.usgs.volcanoes.core;

package gov.usgs.volcanoes.core.quakeml;

public interface QuakemlObserver {
  public void update(QuakemlSource source);
}

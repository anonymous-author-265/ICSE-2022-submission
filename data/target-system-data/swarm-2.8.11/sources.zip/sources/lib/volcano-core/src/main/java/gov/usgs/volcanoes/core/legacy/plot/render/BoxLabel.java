package gov.usgs.volcanoes.core.legacy.plot.render;

import java.awt.Graphics2D;

/**
 * <p>Renderer for box labels. Does nothing.</p>
 * 
 * $Log: not supported by cvs2svn $
 * @author Dan Cervelli
 */
public class BoxLabel implements Renderer {

  public void render(Graphics2D g) {}

}

/**
 * contrib holds classes contributed by others. Each file has is covered by its own license as
 * indicated in the file.
 *
 */
package gov.usgs.volcanoes.core.contrib;

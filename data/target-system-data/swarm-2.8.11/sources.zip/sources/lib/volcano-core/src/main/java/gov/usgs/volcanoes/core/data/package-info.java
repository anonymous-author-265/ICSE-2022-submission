/**
 * Classes to hold or process data types.
 * 
 */
package gov.usgs.volcanoes.core.data;
